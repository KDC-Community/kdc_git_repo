"YOU" have to 


--- download and install the following script.modules first:---

script.module.limitless-swiftstreamz
script.module.limitless-tvtap
script.module.7of9-motherless
script.module.7of9-videodevil
script.module.7of9-pirateslife4me
script.module.fvg
script.module.wvg



--------------------------
download the RasPi_Kodi_Deutschland_Community.xml 
and download
the Sport.xml 
and kn1.m3u
and kn2.m3u

and transfer / kick it on your kodi system in this folder!!!!!!!!!!!!!!!!!!

/storage/.kodi/userdata/playlists/video/


-----------------------------------------------------------------------------

then install livestreamspro addon
and open.

in livestreamspro addon options / add source / choose source type (choose file insteet of url!!!)
then 
choose the copied file source:
/storage/.kodi/userdata/playlists/video/RasPi_Kodi_Deutschland_Community.xml 

then
add source and open with LiveStreamsPro addon!



and have4un!

------ Raspberry Pi Kodi Deutschland Community ------
https://www.facebook.com/groups/raspikdc
