This is an automatically generated repository for the KODI distribution of
xbmcswift2. Only use this repository if you know what you are doing.

This version is python2 only (gotham-matrix)