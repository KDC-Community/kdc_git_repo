![I Love Hirschmilch](icon.png)

KODI - Audio Addon - I Love Hirschmilch.



* [Download the Ctrl_Esc_REPO Version-4.8.1](https://github.com/KDC-Community/kdc_git_repo/raw/master/zips/plugin.audio.i_love_hirschmilch/plugin.audio.i_love_hirschmilch-4.8.1.zip)


