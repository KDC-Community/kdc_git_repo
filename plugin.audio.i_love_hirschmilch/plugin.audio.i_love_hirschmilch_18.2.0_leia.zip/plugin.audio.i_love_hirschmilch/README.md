![I Love Hirschmilch](icon.png)

KODI - Audio Addon for I Love Hirschmilch.



* [Download the Ctrl_Esc_REPO Version-2019.10.10.](https://github.com/KDC-Community/kdc_git_repo/raw/master/zips/plugin.audio.i_love_hirschmilch/plugin.audio.i_love_hirschmilch-2019.10.10.zip)

* [Download the Ctrl_Esc_REPO Version-18.2.0_leia](https://github.com/KDC-Community/kdc_git_repo/raw/master/zips/plugin.audio.i_love_hirschmilch/plugin.audio.i_love_hirschmilch_18.2.0_leia.zip)

* [Download the Ctrl_Esc_REPO Version-19.2.0_matrix](https://github.com/KDC-Community/kdc_git_repo/raw/master/zips/plugin.audio.i_love_hirschmilch/plugin.audio.i_love_hirschmilch_19.2.0_matrix.zip)

* [Download the Ctrl_Esc_REPO Version-18.1.3_leia](https://github.com/KDC-Community/kdc_git_repo/raw/master/zips/plugin.audio.i_love_hirschmilch/plugin.audio.i_love_hirschmilch_18.1.3_leia.zip)
