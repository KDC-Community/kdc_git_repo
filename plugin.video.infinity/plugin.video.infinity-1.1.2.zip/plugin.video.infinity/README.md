![Infinity icon](https://raw.githubusercontent.com/deepship/plugin.video.infinity/nightly/icon.png)
## Willkommen bei Infinity für Kodi!

Bei Infinity handelt es sich um ein Video-Addon für Kodi, welches das Streamen von Filmen und Serien über eine optisch ansprechende Benutzeroberfläche ermöglicht

Wir suchen Python Entwickler die am Project mitwirken möchten, Kontakt über den Chat oder Änderungen als PullRequest einreichen

Das oberste Ziel ist es, Indexseiten zu fixen

Der Funktionsumfang von Infinity ist zur Zeit wegen fehlender Entwickler eingeschränkt, mache Inndexseiten sind ohne Funktion

Webseiten werden auch als Indexseiten bezeichnet, welche auf die eigentlichen Quellen verweisen, die für das bereitgestellte Angebot verantworlich sind! 

Infinity dient nur als Suchmaschine und hostet selbst keine Dateien

[![Join the chat at https://gitter.im/Lastship_Chat/Lobby](https://badges.gitter.im/Lastship_Chat/Lobby.svg)](https://gitter.im/Lastship_Chat/Lobby?utm_source=badge&utm_medium=badge&utm_campaign=pr-badge&utm_content=badge)
