# PyHDHR
A Python interface for the HDHomeRun JSON API
