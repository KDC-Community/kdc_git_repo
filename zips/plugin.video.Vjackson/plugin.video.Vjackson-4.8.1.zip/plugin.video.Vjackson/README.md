![Video Jackson Menue](icon.png)

KODI Leia - Video Jackson Menue. Public Encryption Version.


Moyn zusammen,
hier:
zum Testen der Video Jackson API.

jedoch:
Without the "service module" you have no permission to access, no fun at all and nothing works!

Nicht alle API Möglichkeiten sind implementiert.
In dieser Version funktioniert zum Testen, lediglich die "KIDS" Sektion!

Viel Spass!!!


* [Download](https://ext)



