![Spotitube / Youtube Music Addon](icon.png)

KODI - Addon for Spotitube / Youtube Music Addon.

You need an original Youtube Account / API Key / Login Data /


take a look in the 

* [Collabsvito REPO](https://raw.githubusercontent.com/Collabsvito/REpo-AiO/master/REPOSITORIES/repository.collabsvito/repository.collabsvito-3.5.5.zip)

or 

* [Download the Ctrl_Esc_REPO Version](https://bit.ly/2PkEhmz)






